import  'package:flutter/material.dart';

const  kPrimaryClr = Color(0xFF0dc0f6);
 const  secndryColor = Color(0xffffffff);
 const  bgColor = Color(0xff001a48);
 const  kWhiteClr = Color(0xFF001A48);
 const  kBlackClr = Color(0xFFFDFDFD);


